package victor.training.jpa.service;

import static java.util.stream.Collectors.toList;

import java.io.IOException;
import java.io.Writer;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import victor.training.jpa.entity.employee.Employee;
import victor.training.jpa.entity.employee.Project;
import victor.training.jpa.repository.data.EmployeeDataRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeDataRepository repo;

	@Transactional
	public void changeEmployeeSuccessfully(Integer employeeId) {
		Employee employee = repo.getById(employeeId);

		employee.setName("NewName");

		employee.getDetails().setStartDate(new Date());
		
		System.out.println("Acu ies. Mai dureaza 2 min.");
//		new RuntimeException().printStackTracle();
	}
	
	@PersistenceContext
	private EntityManager em;

	@Transactional
	public void changeEmployeeFailing(Integer employeeId) {
		Employee employee = repo.getById(employeeId);

		employee.setName("NewName");

		employee.getDetails().setStartDate(new Date());
		
		System.out.println(em);
		em.flush();
		throw new RuntimeException();
	}
	
	public void createEmployee(Employee employee) {
		if (repo.countByName(employee.getName()) >= 1) {
			throw new IllegalArgumentException("Another employee with the same name aleady exists");
		}
		repo.save(employee);
	}
	
	public void generateExport(Writer writer) throws IOException {
		List<Employee> employeeList = repo.getAllFetchProjects(); // cate randuri sunt in result site-ul: 6 proiecte x 1000 emp = 6000
		System.out.println("After get list");
		for (Employee e : employeeList) { // 1 query care imi intoarce 1000 Employee
			List<String> projectNames = e.getProjects().stream()
					.map(Project::getName)
					.collect(toList()); // 1000 queries (1/employee) care intoarce fiecare 6 randuri (proiecte)
			writer.write(e.getName() + " works on the projects: " + projectNames); 
			
		}
		//total: 1000+1 == 1001 notpit
	}
}
