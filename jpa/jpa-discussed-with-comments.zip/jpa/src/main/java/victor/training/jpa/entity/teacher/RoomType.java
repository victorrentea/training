package victor.training.jpa.entity.teacher;

public enum RoomType {
	AULA, CLASSROOM, LIBRARY
}
