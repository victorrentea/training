package victor.training.jpa.entity.employee;

public enum ProjectType {
	PUBLIC, PRIVATE
}
