package caplin.tdd;

public class FizzBuzzTest2 {

}
