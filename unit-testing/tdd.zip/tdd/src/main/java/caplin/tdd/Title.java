package caplin.tdd;

/**
 * Created by nicolaes on 08/01/2016.
 */
public interface Title {
}
