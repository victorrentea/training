package victor.training.jpa.repository;

import victor.training.jpa.entity.teacher.RoomType;

public class CourseSearchCriteria {
	public String namePart;
	public Integer teacherId;
	public RoomType roomType;
	public Integer studentId;
}