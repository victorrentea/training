package ro.victor.training.jpa.orm.advanced.entity;

public class Developer {
}
