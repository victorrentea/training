package com.gildedrose;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;

import org.junit.Test;

import com.gildedrose.strategy.AgedBrieStrategy;
import com.gildedrose.strategy.BackstageStrategy;
import com.gildedrose.strategy.ConjuredStrategy;
import com.gildedrose.strategy.SulfurasStrategy;

public class TexttestFixture {
	@Test
	public void characterizationTest() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream myPrintStream = new PrintStream(baos);
		System.setOut(myPrintStream );
        System.out.println("OMGHAI!");

        Item[] items = new Item[] {
                new Item("+5 Dexterity Vest", 10, 20), //
                new Item("Aged Brie", 2, 0), //
                new Item("Aged Brie", 0, 0), //
                new Item("Elixir of the Mongoose", 5, 7), //
                new Item("Sulfuras, Hand of Ragnaros", 0, 80), //
                new Item("Sulfuras, Hand of Ragnaros", -1, 80),
                new Item("Backstage passes to a TAFKAL80ETC concert", 15, 20),
                new Item("Backstage passes to a TAFKAL80ETC concert", 10, 20),
                new Item("Backstage passes to a TAFKAL80ETC concert", 5, 20),
                new Item("Backstage passes to a TAFKAL80ETC concert", 10, 49),
                new Item("Backstage passes to a TAFKAL80ETC concert", 5, 49),
                // this conjured item does not work properly yet
                new Item("Conjured Mana Cake", 3, 6) };

        GildedRose app = new GildedRose(items);
        app.setStrategies(Arrays.asList(
    			new AgedBrieStrategy(),
    			new BackstageStrategy(),
    			new SulfurasStrategy(),
    			new ConjuredStrategy()
            ));

        int days = 2;

        for (int i = 0; i < days; i++) {
            System.out.println("-------- day " + i + " --------");
            System.out.println("name, sellIn, quality");
            for (Item item : items) {
                System.out.println(item);
            }
            app.updateQuality();
        }
        
        String expected = "OMGHAI!\r\n"
        		+ "-------- day 0 --------\r\n"
        		+ "name, sellIn, quality\r\n"
        		+ "+5 Dexterity Vest, 10, 20\r\n"
        		+ "Aged Brie, 2, 0\r\n"
        		+ "Aged Brie, 0, 0\r\n"
        		+ "Elixir of the Mongoose, 5, 7\r\n"
        		+ "Sulfuras, Hand of Ragnaros, 0, 80\r\n"
        		+ "Sulfuras, Hand of Ragnaros, -1, 80\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 15, 20\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 10, 20\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 5, 20\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 10, 49\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 5, 49\r\n"
        		+ "Conjured Mana Cake, 3, 6\r\n"
        		+ "-------- day 1 --------\r\n"
        		+ "name, sellIn, quality\r\n"
        		+ "+5 Dexterity Vest, 9, 19\r\n"
        		+ "Aged Brie, 1, 1\r\n"
        		+ "Aged Brie, -1, 2\r\n"
        		+ "Elixir of the Mongoose, 4, 6\r\n"
        		+ "Sulfuras, Hand of Ragnaros, 0, 80\r\n"
        		+ "Sulfuras, Hand of Ragnaros, -1, 80\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 14, 21\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 9, 22\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 4, 23\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 9, 50\r\n"
        		+ "Backstage passes to a TAFKAL80ETC concert, 4, 50\r\n"
        		+ "Conjured Mana Cake, 2, 4\r";
        
        assertEquals(expected.trim(), new String(baos.toByteArray()).trim());
    }

}
