package com.gildedrose;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

import com.gildedrose.strategy.AgedBrieStrategy;
import com.gildedrose.strategy.BackstageStrategy;
import com.gildedrose.strategy.SulfurasStrategy;

public class GildedRoseTest {

    @Test
    public void foo() {
        Item[] items = new Item[] { new Item("foo", 0, 0) };
        GildedRose app = new GildedRose(items);
        app.setStrategies(Arrays.asList(
			new AgedBrieStrategy(),
			new BackstageStrategy(),
			new SulfurasStrategy()
        ));
        app.updateQuality();
        assertEquals("fixme", app.items[0].name);
    }

}
