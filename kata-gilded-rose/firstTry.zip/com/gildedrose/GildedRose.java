package com.gildedrose;

import java.util.List;

import com.gildedrose.strategy.DefaultStrategy;
import com.gildedrose.strategy.ItemStrategy;

public class GildedRose {
	
	Item[] items;
	
	private List<ItemStrategy> strategies;

	public GildedRose(Item[] items) {
		this.items = items;
	}
	
	public void setStrategies(List<ItemStrategy> strategies) {
		this.strategies = strategies;
	}
	
	public void updateQuality() {
		for (Item item : items) {
			decideStrategy(item).updateItem(item);
		}
	}

	private ItemStrategy decideStrategy(Item item) {
		return strategies.stream()
			.filter(strategy -> strategy.canHandle(item))
			.findFirst()
			.orElse(new DefaultStrategy());
	}

	public static void decreaseQuality(Item item, int delta) {
		item.quality -= delta;
		if (item.quality < 0) {
			item.quality = 0;
		}
	}

	public static void increaseQuality(Item item, int delta) {
		item.quality += delta;
		if (item.quality > 50) {
			item.quality = 50;
		}
	}
}
