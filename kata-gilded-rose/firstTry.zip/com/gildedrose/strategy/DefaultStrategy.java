package com.gildedrose.strategy;

import com.gildedrose.GildedRose;
import com.gildedrose.Item;

public class DefaultStrategy implements ItemStrategy {
	public void updateItem(Item item) {
		GildedRose.decreaseQuality(item, 1);
		item.sellIn--;
		if (item.sellIn < 0) {
			GildedRose.decreaseQuality(item, 1);
		}
	}

	@Override
	public boolean canHandle(Item item) {
		return true;
	}
}