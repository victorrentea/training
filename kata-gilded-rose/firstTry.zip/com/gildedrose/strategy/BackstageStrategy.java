package com.gildedrose.strategy;

import com.gildedrose.GildedRose;
import com.gildedrose.Item;

public class BackstageStrategy implements ItemStrategy {
	private static final String BACKSTAGE = "Backstage passes to a TAFKAL80ETC concert";
	public void updateItem(Item item) {
		if (item.sellIn <= 5) {
			GildedRose.increaseQuality(item, 3);
		} else if (item.sellIn <= 10) {
			GildedRose.increaseQuality(item, 2);
		} else {
			GildedRose.increaseQuality(item, 1);
		};
		item.sellIn--;
		
		if (item.sellIn < 0) {
			item.quality = 0;
		}
	}

	public boolean canHandle(Item item) {
		return BACKSTAGE.equals(item.name);
	}
}