package com.gildedrose.strategy;

import com.gildedrose.Item;

public interface ItemStrategy {
	boolean canHandle(Item item);
	void updateItem(Item item);
}