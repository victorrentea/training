package com.gildedrose.strategy;

import com.gildedrose.GildedRose;
import com.gildedrose.Item;

public class AgedBrieStrategy implements ItemStrategy {
	private static final String AGED_BRIE = "Aged Brie";
	public void updateItem(Item item) {
		GildedRose.increaseQuality(item, 1);
		item.sellIn--;
		if (item.sellIn < 0) {
			GildedRose.increaseQuality(item, 1);
		}
	}
	public boolean canHandle(Item item) {
		return AGED_BRIE.equals(item.name);
	}
}