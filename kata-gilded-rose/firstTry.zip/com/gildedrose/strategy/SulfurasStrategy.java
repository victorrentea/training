package com.gildedrose.strategy;

import com.gildedrose.Item;

public class SulfurasStrategy implements ItemStrategy {
	private static final String SULFURAS = "Sulfuras, Hand of Ragnaros";
	public void updateItem(Item item) {
	}
	public boolean canHandle(Item item) {
		return SULFURAS.equals(item.name);
	}
}