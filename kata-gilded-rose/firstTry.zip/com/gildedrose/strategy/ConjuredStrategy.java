package com.gildedrose.strategy;

import com.gildedrose.GildedRose;
import com.gildedrose.Item;

public class ConjuredStrategy implements ItemStrategy {
	private static final String CONJURED = "Conjured Mana Cake";
	public void updateItem(Item item) {
		GildedRose.decreaseQuality(item, 2);
		item.sellIn--;
		if (item.sellIn < 0) {
			GildedRose.decreaseQuality(item, 2);
		}
	}
	public boolean canHandle(Item item) {
		return CONJURED.equals(item.name);
	}
}