package victor.kata.parking;

public class DisabledBay implements Bay{

	private boolean occupied;
	private int index;
	
	public DisabledBay(int index) {
		this.index = index;
	}

	public boolean isFree() {
		return !occupied; 
	}

	public char getCar() {
		return 'D'; 
	}

	public char toFormattedBay() {
		return occupied ? 'D' : '@'; 
	}

	public boolean isPedestrianExit() {
		return false; 
	}

	public void park(char carType) {
		 occupied = true;
	}

	public void unpark() {
		occupied = false;
	}

	public int getIndex() {
		return index; 
	}
}
