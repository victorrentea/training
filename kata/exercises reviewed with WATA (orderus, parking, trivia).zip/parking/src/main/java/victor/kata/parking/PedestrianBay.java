package victor.kata.parking;

import org.apache.commons.lang3.NotImplementedException;

public class PedestrianBay  implements Bay{

	private int index;

	public PedestrianBay(int index) {
		this.index = index;
	}

	public boolean isFree() {
		return false; 
	}

	public char getCar() {
		throw new NotImplementedException("No car can be here");
	}

	public char toFormattedBay() {
		return '=';
	}

	public boolean isPedestrianExit() {
		return true; 
	}

	public void park(char carType) {
		throw new IllegalStateException("Park bay is a Pedrestian exit");
	}

	public void unpark() {
		throw new IllegalStateException("Park bay is a Pedrestian exit");
	}

	public int getIndex() {
		return index; 
	}

}
