package victor.kata.parking;

public interface Bay {
	boolean isFree();
	char getCar();

	void unpark();
	void park(char carType);

	char toFormattedBay();
	boolean isPedestrianExit();
	int getIndex();
}
