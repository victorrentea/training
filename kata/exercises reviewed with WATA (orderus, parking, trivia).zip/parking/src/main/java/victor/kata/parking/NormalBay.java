package victor.kata.parking;

public class NormalBay implements Bay {

	// the convention: if car == ' ', then the slot is free
	private int index;
	private char car = ' ';

	public NormalBay(int index) {
		this.index = index;
	}
	public int getIndex() {
		return index;
	}
	public boolean isFree() {
		return car == ' ';
	}
	public char getCar() {
		return car; 
	}
	
	public void unpark() {
		car = ' ';
	}
	
	public void park(char carType) {
		this.car = carType;
	}
	
	public boolean isPedestrianExit() {
		return false;
	}
	
	public char toFormattedBay() {
		return car == ' ' ? 'U' : car;
	}
	
	
//	 {
//			return 
//					this.status == BayStatus.DISABLED_EMPTY || 
	
	
//	(this.status == BayStatus.NORMAL_EMPTY && 
//			this.car == ' ');
//		}
	
}
