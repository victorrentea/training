package victor.kata.parking;

import java.util.HashSet;
import java.util.Set;

/**
 * Builder class to get a parking instance
 */
public class ParkingBuilder {
	private int size = 0;
	private Set<Integer> pedestrianExitIndexes = new HashSet<>();
	private Set<Integer> disabledBayIndexes = new HashSet<>();

	public ParkingBuilder withSquareSize(int size) {
		this.size = size;
		return this;
	}

	public ParkingBuilder withPedestrianExit(int pedestrianExitIndex) {
		if (!isValidParkingIndex(pedestrianExitIndex)) {
			throw new IllegalArgumentException("No such parking bay");
		}
		this.pedestrianExitIndexes.add(pedestrianExitIndex);
		return this;
	}

	public ParkingBuilder withDisabledBay(int disabledBayIndex) {
		if (!isValidParkingIndex(disabledBayIndex)) {
			throw new IllegalArgumentException("No such parking bay");
		}
		this.disabledBayIndexes.add(disabledBayIndex);
		return this;
	}

	private boolean isValidParkingIndex(int pedestrianExitIndex) {
		return pedestrianExitIndex < (this.size * this.size);
	}

	public Parking build() {
		if (size <= 0) {
			throw new IllegalStateException("Parking size not valid");
		}
		return new Parking(size, pedestrianExitIndexes, disabledBayIndexes);
	}
}