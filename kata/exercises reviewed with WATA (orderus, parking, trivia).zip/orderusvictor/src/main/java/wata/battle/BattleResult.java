package wata.battle;

public enum BattleResult {
	TIE, FIRST_WINS, SECOND_WINS
}
