package wata.skill;

public enum SkillType{
	ATTACK, DEFENSE
}