package trivia;

public class Player {
	private final String name;
	private int position;
	private boolean inPenaltyBox;
	private int purses;

	public Player(String name) {
		this.name = name;
		this.position = 0;
		this.inPenaltyBox = false;
		this.purses = 0;
	}

	/**
	 * Push player some positions forward/backwards
	 * 
	 * @param steps
	 * @return position after movement
	 */
	public int move(int steps) {
		this.position += steps;
		return this.position;
	}

	public boolean isInPenaltyBox() {
		return inPenaltyBox;
	}

	public String getName() {
		return this.name;
	}

	public int getPurses() {
		return this.purses;
	}

	public int getPosition() {
		return this.position;
	}

	public void setInPenaltyBox(boolean inPenaltyBox) {
		this.inPenaltyBox = inPenaltyBox;
	}
	
	public void addPurse() {
		this.purses++;
	}
	
}
