package trivia;

public enum Category {
	POP("Pop"), SCIENCE("Science"), SPORTS("Sports"), ROCK("Rock");
	
	private String name;

	private  Category(String type) {
		this.name = type;
	}
	
	public String getName() {
		return this.name;
	}
	
}
