package trivia;

public class Question {
	private final int index;
	private final Category category;

	public Question(Category type, int index) {
		this.index = index;
		this.category = type;
	}

	public String printQuestion() {
		return this.category.getName() + " Question " + this.index;
	}

}
