package trivia;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class BetterGame implements IGame {
	private static final int MAX_PURSES = 6;
	private static final int NUM_QUESTIONS_X_CATEGORY = 50;
	private static final int QUESTIONS_X_CATEGORY = 3;
	private static final int MIN_NUMBER_OF_PLAYERS = 2;
	
	private final List<Player> players = new ArrayList<>();
	
	private final Map<Category, List<Question>> questions = new HashMap<>();

	private final List<Category> board = new ArrayList<>();

	private int currentPlayerIndex = 0;
	private boolean canGetOutOfPenaltyBoxIfAnswersCorrectly = false;

	public BetterGame() {
		initQuestionsCategories();
		fillCategoriesWithQuestions();
		initBoardWithCategories();
	}

	private void initQuestionsCategories() {
		for (Category category : Category.values()) {
			questions.put(category, new LinkedList<Question>());
		}
	}

	private void fillCategoriesWithQuestions() {
		for (int i = 0; i < NUM_QUESTIONS_X_CATEGORY; i++) {
			for (Category category : Category.values()) {
				List<Question> questionsByCategory = questions.get(category);
				questionsByCategory.add(new Question(category, i));
			}
		}
	}

	private void initBoardWithCategories() {
		for (Integer i = 0; i < getBoardSize(); i++) {
			for (Category category : Category.values()) {
				board.add(category);
			}
		}
	}

	private int getBoardSize() {
		return QUESTIONS_X_CATEGORY * Category.values().length;
	}

	@Override
	public boolean isPlayable() {
		return howManyPlayers() >= MIN_NUMBER_OF_PLAYERS;
	}

	@Override
	public boolean add(String playerName) {
		players.add(new Player(playerName));
		System.out.println(playerName + " was added");
		System.out.println("They are player number " + players.size());
		return true;
	}

	@Override
	public int howManyPlayers() {
		return players.size();
	}

	@Override
	public void roll(int roll) {
		System.out.println(getCurrentPlayer().getName() + " is the current player");
		System.out.println("They have rolled a " + roll);
		applyRoll(roll);
	}

	private void applyRoll(int roll) {
		if (!getCurrentPlayer().isInPenaltyBox() || isOdd(roll)) {
			if (getCurrentPlayer().isInPenaltyBox()) {
				//so, he is in Penalty. And throws the dice '3'. 
				// He then has the chance of exiting the penalty box 
				// if he answers correctly ? 
				playerIsGoingOutFromPenaltyBox();
			}
			updateCurrentPlayerPosition(roll);
			askQuestion();
		} else {
			keepCurrentPlayerInsideThePenaltyBox();
		}
	}

	private void playerIsGoingOutFromPenaltyBox() {
		canGetOutOfPenaltyBoxIfAnswersCorrectly = true;
		System.out.println(getCurrentPlayer().getName() + " is getting out of the penalty box");
	}

	private void keepCurrentPlayerInsideThePenaltyBox() {
		System.out.println(getCurrentPlayer().getName() + " is not getting out of the penalty box");
		canGetOutOfPenaltyBoxIfAnswersCorrectly = false;
	}

	private void updateCurrentPlayerPosition(int roll) {
		getCurrentPlayer().move(roll);
		resetCurrentPlayerPosition();
		System.out.println(getCurrentPlayer().getName() + "'s new location is " + getCurrentPlayer().getPosition());
	}

	private void resetCurrentPlayerPosition() {
		if (getCurrentPlayer().getPosition() >= getBoardSize()) {
			getCurrentPlayer().move(-1 * getBoardSize());
		}
	}

	private boolean isOdd(int roll) {
		return roll % 2 != 0;
	}

	private void askQuestion() {
		Category currentCategory = getCurrentCategory();
		System.out.println("The category is " + currentCategory.getName());
		System.out.println(questions.get(currentCategory).remove(0).printQuestion());
	}

	private Category getCurrentCategory() {
		return board.get(getCurrentPlayer().getPosition());
	}

	@Override
	public boolean wasCorrectlyAnswered() {
		boolean notWinner = true;
//		if (!a || (a && b)); === if (!a || b)
		// if (!a) {true} else if (b) {true}
		if (!getCurrentPlayer().isInPenaltyBox() || canGetOutOfPenaltyBoxIfAnswersCorrectly) {
			System.out.println("Answer was correct!!!!");
//			getCurrentPlayer().setInPenaltyBox(false); BUG BUG BUG
			addPurseToCurrentPlayer();
			notWinner = !isCurrentPlayerWinner();
		}
		updateCurrentPlayerIndex();
		return notWinner;
	}

	// HOW MANY CPU CYCLES will this function take ?
	// <=1 ?!?!!!
	private Player getCurrentPlayer() {
		return players.get(currentPlayerIndex);
	}

	private void addPurseToCurrentPlayer() {
		getCurrentPlayer().addPurse();
		System.out.println(getCurrentPlayer().getName() + " now has " + getCurrentPlayer().getPurses() + " Gold Coins.");
	}

	private void updateCurrentPlayerIndex() {
		currentPlayerIndex++;
		if (currentPlayerIndex == players.size())
			currentPlayerIndex = 0;
		// getCurrentPlayer()Index = (getCurrentPlayer()Index + 1) % players.size();
	}

	@Override
	public boolean wrongAnswer() {
		System.out.println("Question was incorrectly answered");
		sendPlayerToPenaltyBox();
		updateCurrentPlayerIndex();
		return true;
	}
	
	private void sendPlayerToPenaltyBox() {
		System.out.println(getCurrentPlayer().getName() + " was sent to the penalty box");
		getCurrentPlayer().setInPenaltyBox(true);
	}

	private boolean isCurrentPlayerWinner() {
		return getCurrentPlayer().getPurses() == MAX_PURSES;
	}

}
