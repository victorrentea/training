/*  Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

package babysteps;

import java.text.DecimalFormat;

public class BabystepsTimer {
	private enum Status {
		NEUTRAL("#ffffff"),
		FAILED("#ffcccc"),
		PASSED("#ccffcc");
		public String backgroundColor;

		private Status(String color) {
			this.backgroundColor = color;
		}
	}

	private final long SECONDS_IN_CYCLE = 6;

	
	private long currentCycleStartTime;
	private Status currentStatus = Status.NEUTRAL;
	
	private SoundPlayer soundPlayer = new SoundPlayer();
	
	private static DecimalFormat twoDigitsFormat = new DecimalFormat("00");
	
	private final UI ui = new UI(this);
	private TimerThread timerThread = new TimerThread(this::doStuff);
	
	public void start(long now) {
		currentCycleStartTime = now;
		timerThread.start();
		showRemainingSeconds(SECONDS_IN_CYCLE, Status.NEUTRAL);
	}
	
	public void stop() {
		timerThread.stop();
		showRemainingSeconds(SECONDS_IN_CYCLE, Status.NEUTRAL);
	}
	
	public void reset(long now) {
		currentCycleStartTime = now;
		currentStatus=Status.PASSED;
	}

	public static void main(final String[] args) throws InterruptedException {
		new BabystepsTimer().myMain();
	}
	public void myMain() {
		ui.build();
		showRemainingSeconds(SECONDS_IN_CYCLE, Status.NEUTRAL);
	}

	private String remainingSecondsToCaption(long remainingSeconds) {
		long remainingMinutes = remainingSeconds/60;
		return twoDigitsFormat.format(remainingMinutes)+":"+twoDigitsFormat.format(remainingSeconds-remainingMinutes*60);
	}

	
	private long lastRemainingSeconds;
	
	public void doStuff(long currentTimeMillis) {
		long elapsedTime = currentTimeMillis - currentCycleStartTime;
		
		if(elapsedTime >= SECONDS_IN_CYCLE*1000+980) {
			currentCycleStartTime = currentTimeMillis;
			elapsedTime = currentTimeMillis - currentCycleStartTime;
		}
		if(elapsedTime >= 5000 && elapsedTime < 6000 && !Status.NEUTRAL.equals(currentStatus)) {
			currentStatus = Status.NEUTRAL;
		}
		long elapsedSeconds = elapsedTime/1000;
		long remainingSeconds = SECONDS_IN_CYCLE - elapsedSeconds;
		
		if (lastRemainingSeconds != remainingSeconds) {
			if(remainingSeconds == 10) {
				soundPlayer.playLittleTimeLeft();
			} else if(remainingSeconds == 0) {
				soundPlayer.playTimesUp();
				currentStatus=Status.FAILED;
			}
			
			showRemainingSeconds(remainingSeconds, currentStatus);
			
			lastRemainingSeconds = remainingSeconds;
		}
	}

	private void showRemainingSeconds(long remainingSeconds, Status status) {
		ui.setText(remainingSecondsToCaption(remainingSeconds), status.backgroundColor, timerThread.isRunning());
	}
}
