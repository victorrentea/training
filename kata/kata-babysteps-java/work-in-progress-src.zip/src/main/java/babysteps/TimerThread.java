package babysteps;

public class TimerThread implements Runnable {
	public interface Task {
		void doStuff(long currentTimeMillis);
	}
	private boolean running;
	
	private final Task task;
	
	public TimerThread(Task task) {
		this.task = task;
	}

	public synchronized void start() {
		if (!running) {
			running = true;
			new Thread(this).start();
		}
	}
	
	public void run() {
		while(running) {
			long currentTimeMillis = System.currentTimeMillis();
			task.doStuff(currentTimeMillis);
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				//We don't really care about this one...
			}
		}
	}
	public synchronized void stop() {
		running = false;
	}
	
	public boolean isRunning() {
		return running;
	}
}