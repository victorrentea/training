package com.gildedrose;

import static java.util.stream.Collectors.joining;
import static org.junit.Assert.*;

import java.util.stream.Stream;

import org.junit.Test;

public class GildedRoseTest {

    @Test
    public void foo() {
    	GildedRose originalApp = new GildedRose(TexttestFixture.testItems());
    	GildedRoseNew newApp = new GildedRoseNew(TexttestFixture.testItems());

        for (int i = 0; i < 5; i++) {
            System.out.println("-------- day " + i + " --------");
            
            String expected = Stream.of(originalApp.getItems()).map(Object::toString).collect(joining("\n"));
            String actual = Stream.of(newApp.getItems()).map(Object::toString).collect(joining("\n"));
            System.out.println(expected);
            
            assertEquals("Day " + i, expected, actual);
            originalApp.updateQuality();
            newApp.updateQuality();
        }
    }

}
