package com.gildedrose;

import java.util.function.BiFunction;
import java.util.stream.Stream;

class GildedRoseNew {
    Item[] items;
    
    enum ItemType {
    	REGULAR("", GildedRoseNew::getNewQualityRegular),
    	CONJURED("Conjured", GildedRoseNew::getNewQualityConjured),
    	SULFURAS("Sulfuras, Hand of Ragnaros", GildedRoseNew::getNewQualitySulfuras),
    	CONCERT("Backstage passes to a TAFKAL80ETC concert", GildedRoseNew::getNewQualityConcert),
    	AGED_BRIE("Aged Brie", GildedRoseNew::getNewQualityAgedBrie);
    	
    	private String name;
		public BiFunction<Integer, Integer, Integer> getNewQuality;

		ItemType(String name, BiFunction<Integer, Integer, Integer> getNewQuality) {
			this.name = name;
			this.getNewQuality = getNewQuality;
    	}
		
		public static ItemType of(String itemName) {
			return Stream.of(values())
				.filter(type -> type.name.equals(itemName))
				.findAny()
				.orElse(REGULAR);
		}
    }

    public GildedRoseNew(Item[] items) {
        this.items = items;
    }
    
    public Item[] getItems() {
		return items;
	}

    public void updateQuality() {
        for (Item item : items) {
        	ItemType itemType = ItemType.of(item.name);
			Integer newQuality = itemType.getNewQuality.apply(item.quality, item.sellIn);
        	item.quality = newQuality;

        	if (itemType != ItemType.SULFURAS) {
        		item.sellIn --;
        	}
        }
    }

	private static int getNewQualitySulfuras(int quality, int sellIn) {
		return quality;
	}

	private static int getNewQualityAgedBrie(int quality, int sellIn) {
		quality ++;
    	if (sellIn <= 0) {
    		quality ++;
    	}
		return boundQuality(quality);
	}

	private static int boundQuality(int quality) {
		return Math.max(0, Math.min(50, quality));
	}

	private static int getNewQualityConcert(int quality, int sellIn) {
		quality ++;
        if (sellIn <= 10) quality ++;
        if (sellIn <= 5) quality ++;
        if (sellIn <= 0) quality = 0;
		return boundQuality(quality);
	}

	private static int getNewQualityRegular(int quality, int sellIn) {
		quality --;
		if (sellIn <= 0) {
			quality --;
		}
		return boundQuality(quality);
	}
	
	private static int getNewQualityConjured(int quality, int sellIn) {
		quality -= 2;
		if (sellIn <= 0) {
			quality -= 2;
		}
		return boundQuality(quality);
	}

}
