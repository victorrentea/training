package com.gildedrose;

public class ItemQualityCalculator {

}
