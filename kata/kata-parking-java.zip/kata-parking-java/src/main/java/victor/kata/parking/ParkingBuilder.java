package victor.kata.parking;

import org.apache.commons.lang3.NotImplementedException;

/**
 * Builder class to get a parking instance
 */
public class ParkingBuilder {

    public ParkingBuilder withSquareSize(final int size) {
        throw new NotImplementedException("TODO");
    }

    public ParkingBuilder withPedestrianExit(final int pedestrianExitIndex) {
        throw new NotImplementedException("TODO");
    }

    public ParkingBuilder withDisabledBay(final int disabledBayIndex) {
        throw new NotImplementedException("TODO");
    }

    public Parking build() {
        throw new NotImplementedException("TODO");
    }
}
