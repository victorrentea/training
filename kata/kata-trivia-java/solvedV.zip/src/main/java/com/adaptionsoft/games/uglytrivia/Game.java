package com.adaptionsoft.games.uglytrivia;

import static java.util.stream.Collectors.toCollection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

public class Game {
	private List<Player> players = new ArrayList<>();
    
    private Map<QuestionCategory, List<String>> questions = new HashMap<>();
    
    int currentPlayer = -1;
    boolean isGettingOutOfPenaltyBox;
    
	public Game() {
		for (QuestionCategory category : QuestionCategory.values()) {
			questions.put(category, IntStream.range(0, 50)
					.mapToObj(i -> category.label + " Question " + i)
					.collect(toCollection(LinkedList::new)));
		}
	}

	public boolean isPlayable() {
		return (players.size() >= 2);
	}

	public boolean addPlayer(String playerName) {
	    players.add(new Player(playerName));
	    
	    System.out.println(playerName + " was added");
	    System.out.println("They are player number " + players.size());
		return true;
	}
	
	public void roll(int roll) {
		moveToNextPlayer();
		System.out.println(getCurrentPlayer().name + " is the current player");
		System.out.println("They have rolled a " + roll);
		
		if (getCurrentPlayer().inPenaltyBox) {
			isGettingOutOfPenaltyBox = roll % 2 != 0;
			if (isGettingOutOfPenaltyBox) {
				System.out.println(getCurrentPlayer().name + " is getting out of the penalty box");
			} else {
				System.out.println(getCurrentPlayer().name + " is not getting out of the penalty box");
				return;
			}
		}
		
		getCurrentPlayer().move(roll);
		System.out.println(getCurrentPlayer().name + "'s new location is " + getCurrentPlayer().getPlaces());
		System.out.println("The category is " + currentCategory().label);
		askQuestion();
	}

	private Player getCurrentPlayer() {
		return players.get(currentPlayer);
	}

	private void askQuestion() {
		System.out.println(questions.get(currentCategory()).remove(0));
	}
	
	private QuestionCategory currentCategory() {
		return QuestionCategory.values()[getCurrentPlayer().getPlaces() % QuestionCategory.values().length];
	}

	public void answerCorrect() {
		if (getCurrentPlayer().inPenaltyBox && ! isGettingOutOfPenaltyBox) {
			return;
		}
		System.out.println("Answer was correct!!!!");
		getCurrentPlayer().winPoint();
		System.out.println(getCurrentPlayer().name + " now has " + getCurrentPlayer().getPurses() + " Gold Coins.");
	}
	
	public void answerWrong(){
		System.out.println("Question was incorrectly answered");
		System.out.println(getCurrentPlayer().name + " was sent to the penalty box");
		getCurrentPlayer().inPenaltyBox = true;
	}
	
	public boolean hasPlayerWon() {
		return getCurrentPlayer().hasWon();
	}

	private void moveToNextPlayer() {
		currentPlayer++;
		if (currentPlayer == players.size()) {
			currentPlayer = 0;
		}
	}

	
}
