package com.adaptionsoft.games.uglytrivia;

public enum QuestionCategory {
	POP("Pop"), 
	SCIENCE("Science"), 
	SPORTS("Sports"), 
	ROCK("Rock");
	public String label;
	private QuestionCategory(String label) {
		this.label = label;
	}
}