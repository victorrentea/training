
package com.adaptionsoft.games.trivia.runner;
import java.io.ByteArrayOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Writer;
import java.util.Random;

import com.adaptionsoft.games.uglytrivia.Game;


public class GameRunner {

	private static boolean gameWon;

	public static void main(String[] args) throws IOException {
		
		for (int seed = 0;seed<1000;seed++) {
			
			try (Writer writer = new FileWriter("output/"+seed+".txt")) {
				writer.write(gatherOutput(seed));
			}
		}
	}

	public static String gatherOutput(long seed) {
		Random rand = new Random(seed);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		
		try (PrintStream ps = new PrintStream(baos)) {
			System.setOut(ps);
			Game aGame = new Game();
			
			aGame.addPlayer("Chet");
			aGame.addPlayer("Pat");
			aGame.addPlayer("Sue");
			
		
			do {
				
				aGame.roll(rand.nextInt(5) + 1);
				
				if (rand.nextInt(9) == 7) {
					aGame.answerWrong();
				} else {
					aGame.answerCorrect();
				}
				
			} while (!aGame.hasPlayerWon());
		}
		return new String(baos.toByteArray());
	}
}
