package com.adaptionsoft.games.trivia.runner;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.apache.commons.io.IOUtils;
import org.junit.Test;

public class GameTester {

	@Test
	public void dummy() throws FileNotFoundException, IOException {
		for (File outputFile : new File("output").listFiles()) {
			int inputSeed = Integer.parseInt(outputFile.getName().replace(".txt", ""));
			String expected;
			try (Reader reader = new FileReader(outputFile)) {
				expected = IOUtils.toString(reader);
			}
			String actual = GameRunner.gatherOutput(inputSeed);
			assertEquals("Test seed " + inputSeed, expected, actual);
			
		}
	}
}
