package com.adaptionsoft.games.uglytrivia;

class Player {
	public final String name;
	private int places;
	private int purses;
	public boolean inPenaltyBox;
	public Player(String name) {
		this.name = name;
	}
	
	public void move(int roll) {
		places += roll;
		if (places > 11)  {
			places -= 12;
		}
	}

	public int getPlaces() {
		return places;
	}

	public boolean hasWon() {
		return purses == 6;
	}
	public void winPoint() {
		purses ++;
	}

	public int getPurses() {
		return purses;
	}

}