package com.adaptionsoft.games.trivia;

import static org.junit.Assert.*;

import org.junit.Test;

public class SomeTest {

	@Test
	public void true_is_true() throws Exception {
		assertTrue(false);
	}
}
