<?php

namespace MS\ExamplePHP\ObserverPattern\Model;

class Order
{
    /**
     * @param array $array
     */
    public function loadFromArray(array $array)
    {
    }
}
