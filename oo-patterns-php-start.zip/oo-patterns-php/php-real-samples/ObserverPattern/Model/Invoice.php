<?php

namespace MS\ExamplePHP\ObserverPattern\Model;

class Invoice
{
    /**
     * @param Order $order
     */
    public function loadFromOrder(Order $order)
    {
    }
}
