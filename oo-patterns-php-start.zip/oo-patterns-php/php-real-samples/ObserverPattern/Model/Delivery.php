<?php

namespace MS\ExamplePHP\ObserverPattern\Model;

class Delivery
{
    /**
     * @param Order $order
     */
    public function loadFromOrder(Order $order)
    {
    }
}
