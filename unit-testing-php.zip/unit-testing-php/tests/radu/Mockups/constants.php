<?php

const CSV_HEAD = [
    'Part number',
    'Part number key',
    'Product name',
    'CMS Price',
    'Vendor',
    'Offer ID',
    'URL',
    'Buy button',
    'Image',
    'Site price',
];
