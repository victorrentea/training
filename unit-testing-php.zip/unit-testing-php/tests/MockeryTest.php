<?php
/**
 * Created by IntelliJ IDEA.
 * User: VictorRentea
 * Date: 06-Jun-18
 * Time: 08:39 AM
 */

namespace PhpUnitWorkshopTest;



use Mockery\Adapter\Phpunit\MockeryTestCase;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class MockeryTest extends MockeryTestCase
{
    function testWithMockery() {
//        /** @var MockInterface|MyRepo $mockRepo */
        $mockRepo = \Mockery::mock(MyRepo::class);
        $mockRepo->shouldReceive('getNextId')->andReturn(33);
//        $mockRepo->shouldReceive('save')->times(1)->with(\Mockery::on(function($x) {
//            return true;
//        }));
        /** @var Order $arg */
        $arg = null;
//        $mockRepo->expects()->save(\Mockery::any());
        $mockRepo->expects()->save(\Mockery::on($this->captureArg($arg)));
        $myService = new MyService($mockRepo);
        $myService->createOrder();
        self::assertEquals(33, $arg->getId());
    }

    private function captureArg( &$arg ) {
        return function( $argToMock ) use ( &$arg ) {
            $arg = $argToMock;
            return true;
        };
    }

}

class MyService {
    private $myRepo;

    public function __construct(MyRepo $myRepo)
    {
        $this->myRepo = $myRepo;
    }

    public function createOrder()
    {
        $order = new Order();
        $order->setId($this->myRepo->getNextId());
        $order->setCreationDate(new \DateTime());
        $this->myRepo->save($order);
    }
}

interface MyRepo
{
    function getNextId(): int;
    function save(Order $entity): void;
}

class Order {
    /** @var int */
    private $id;
    /** @var \DateTime */
    private $creationDate;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getCreationDate(): \DateTime
    {
        return $this->creationDate;
    }

    public function setCreationDate(\DateTime $creationDate): void
    {
        $this->creationDate = $creationDate;
    }

}





