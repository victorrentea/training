<?php

namespace PhpUnitWorkshopTest;

use PhpUnitWorkshop\MyEntity;
use PhpUnitWorkshop\MyRepositoryInterface;
use PhpUnitWorkshop\MyService;

// PHP Unit 'standard' mocks
class MyServiceTest extends \PHPUnit\Framework\TestCase
{
    /** @var MyService */
    private $service;
    /** @var MyRepositoryInterface|\PHPUnit\Framework\MockObject\MockObject $repository */
    private $repository;

    protected function setUp()
    {
        $this->service = new MyService();

        $this->repository = $this->getMockBuilder(MyRepositoryInterface::class)->getMock();

        $this->service->setRepository($this->repository);
    }

    public function testActivateWillSetActiveTrueOnMyEntity()
    {
        // Given
        $entity = new MyEntity();
        $entity->setActive(false);

        $this->repository->expects($this->once())
            ->method('save')
            ->with($entity);

        // When
        $this->service->activate($entity);

        // Then
        $this->assertTrue($entity->getActive());
    }

    public function testDeactivateWillSetActiveTrueOnMyEntity()
    {
        // Given
        $entity = new MyEntity();
        $entity->setActive(true);

        $this->repository->expects($this->once())
            ->method('save')
            ->with($entity);

        // When
        $this->service->deactivate($entity);

        // Then
        $this->assertFalse($entity->getActive());
    }
}
