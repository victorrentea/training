<?php declare(strict_types=1);

namespace PhpUnitWorkshopTest;

use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;


class WithSymphony extends KernelTestCase
{
    protected function setUp()
    {
        self::bootKernel();
    }

        /** @test */
    public function halloSymphony()
    {
        echo 'oare:' . (static::$kernel == null);
        $em = static::$kernel->getContainer()->get('doctrine')->getManager('mktp_finance_slave');
    }
}