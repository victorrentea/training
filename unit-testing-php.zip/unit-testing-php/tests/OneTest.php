<?php

namespace PhpUnitWorkshopTest;

use PhpUnitWorkshop\A;


use PHPUnit\Framework\TestCase;

class OneTest extends TestCase
{
  
	/** @test */
    public function getRedirectUri()
    {
        echo "ok\n";
		self::assertTrue(true);
    }
	
	/** @test */
    public function doi()
    {
        $sut = new A();
        self::assertEquals(3, $sut->sum(1,2));
    }

    /** @test */
    public function compareArrays()
    {
        self::assertEquals(['a','b'], ['a', new MyObj()]);
    }
}

class MyObj {
    private $s ='Halo';
}