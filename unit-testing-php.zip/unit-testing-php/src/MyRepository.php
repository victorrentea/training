<?php

namespace PhpUnitWorkshop;

class MyRepository implements MyRepositoryInterface
{
    final public function save($entity)
    {
        $fh = fopen('./database.txt', 'w');
        fwrite($fh, serialize($entity));
        fclose($fh);
    }
}
