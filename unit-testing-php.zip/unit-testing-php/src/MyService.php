<?php

namespace PhpUnitWorkshop;

class MyService
{
    /**
     * @var MyRepositoryInterface
     */
    private $repository;

    public function activate(MyEntity $entity)
    {
        $entity->setActive(true);

        $this->repository->save($entity);
    }

    public function deactivate(MyEntity $entity)
    {
        $entity->setActive(false);

        $this->repository->save($entity);
    }

    /**
     * @param MyRepositoryInterface $repository
     * @return MyService
     */
    public function setRepository($repository)
    {
        $this->repository = $repository;

        return $this;
    }
}
