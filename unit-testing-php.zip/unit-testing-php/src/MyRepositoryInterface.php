<?php

namespace PhpUnitWorkshop;

interface MyRepositoryInterface
{
    public function save($entity);
}