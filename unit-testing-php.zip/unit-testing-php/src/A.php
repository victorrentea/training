<?php

namespace PhpUnitWorkshop;



class A
{
  
	public function sum(int $a, int $b) : int
    {
        echo "sum $a+$b\n";
		return $a + $b;
    }

}