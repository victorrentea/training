package my.spring.playground.repo;

import org.springframework.stereotype.Repository;

import my.spring.playground.domain.Student;

@Repository
public class StudentRepository extends BaseRepository<Student> {

}
