package my.spring.playground.repo;

import org.springframework.stereotype.Repository;

import my.spring.playground.domain.Teacher;

@Repository
public class TeacherRepository extends BaseRepository<Teacher>{

}
