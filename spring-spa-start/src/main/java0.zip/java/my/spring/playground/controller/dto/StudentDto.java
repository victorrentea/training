package my.spring.playground.controller.dto;

public class StudentDto {
	public Long id;
	public String name;
}
